import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import io from 'socket.io-client'; // اصلاح ایمپورت پیش‌فرض
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// حل مشکل عدم نمایش آیکون مارکر Leaflet در ری‌آکت
// این کد درست را جایگزین کن:
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cloudflare.com',
  iconUrl: 'https://cloudflare.com',
  shadowUrl: 'https://cloudflare.com',
});

// کامپوننت کمکی برای انتقال وسط نقشه به نقطه جدید
function ChangeMapCenter({ center }) {
  const map = useMap();
  useEffect(() => {
    if (center) {
      map.setView(center, map.getZoom());
    }
  }, [center, map]);
  return null;
}

export default function TruckMap() {
  const [position, setPosition] = useState([36.7022, 67.1132]); // مرکز مزار شریف
  const [truckInfo, setTruckInfo] = useState({ id: 'در انتظار داده...', speed: 0 });

  useEffect(() => {
    // ایجاد اتصال مستقیم به سرور روی پورت ۴۰۰۰
    const socket = io('http://localhost:4000', {
      transports: ['websocket'] // اجبار برای استفاده مستقیم از وب‌سوکت
    });

    socket.on('connect', () => {
      console.log('موفقیت: فرانت‌اند به سرور سوکت وصل شد!');
    });

    socket.on('truck_location_update', (data) => {
      console.log('دیتای جدید دریافتی در کلاینت:', data);
      if (data && data.lat && data.lng) {
        setPosition([data.lat, data.lng]);
        setTruckInfo({
          id: data.truck_id || 'Truck-01',
          speed: data.speed || 0
        });
      }
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  return (
    <div style={{ height: '100vh', width: '100%', position: 'relative' }}>
      <div style={{ position: 'absolute', top: 10, left: 50, zIndex: 1000, background: 'white', padding: 10, borderRadius: 5, boxShadow: '0 2px 5px rgba(0,0,0,0.3)', fontFamily: 'tahoma', direction: 'rtl' }}>
        <h4>کامیون فعال: {truckInfo.id}</h4>
        <p>سرعت زنده: {truckInfo.speed} کیلومتر بر ساعت</p>
      </div>
      
      <MapContainer center={position} zoom={14} style={{ height: '100%', width: '100%' }}>
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://openstreetmap.org">OpenStreetMap</a>'
        />
        <Marker position={position}>
          <Popup>کامیون لجستیک فعال</Popup>
        </Marker>
        <ChangeMapCenter center={position} />
      </MapContainer>
    </div>
  );
}