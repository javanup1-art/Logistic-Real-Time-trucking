import React, { useEffect, useState } from "react";
import { io } from "socket.io-client";

import {
  MapContainer,
  TileLayer,
  Marker,
  Popup,
  useMap,
} from "react-leaflet";

import "leaflet/dist/leaflet.css";
import L from "leaflet";

delete L.Icon.Default.prototype._getIconUrl;

L.Icon.Default.mergeOptions({
  iconRetinaUrl:
    "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",

  iconUrl:
    "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",

  shadowUrl:
    "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
});

function ChangeMapCenter({ center }) {
  const map = useMap();

  useEffect(() => {
    map.setView(center, map.getZoom());
  }, [center]);

  return null;
}

function App() {
  const [position, setPosition] = useState([36.7020, 67.1141]);
  const [speed, setSpeed] = useState(0);
  const [status, setStatus] = useState("در حال اتصال... 🔄");

  useEffect(() => {

    const socket = io(
      "https://shrivel-pretext-gumdrop.ngrok-free.dev",
      {
        transports: ["websocket"],
      }
    );

    socket.on("connect", () => {
      console.log("✅ Connected");

      setStatus("اتصال برقرار شد! ✅");
    });

    socket.on("connect_error", (err) => {
      console.log("❌ Error:", err.message);
    });

    socket.on("disconnect", () => {
      setStatus("اتصال قطع شد! ❌");
    });

    socket.on("update_location", (data) => {

      console.log("📍 Location:", data);

      if (data.lat && data.lng) {
        setPosition([data.lat, data.lng]);
        setSpeed(data.speed || 0);
      }
    });

    return () => socket.disconnect();

  }, []);

  return (
    <div
      style={{
        position: "relative",
        width: "100vw",
        height: "100vh",
        direction: "rtl",
        fontFamily: "Tahoma",
      }}
    >

      <div
        style={{
          position: "absolute",
          top: "20px",
          right: "20px",
          backgroundColor: "white",
          padding: "15px",
          borderRadius: "8px",
          boxShadow: "0 4px 6px rgba(0,0,0,0.1)",
          zIndex: 1000,
          width: "250px",
        }}
      >
        <h3>سامانه لجستیک مزارشریف</h3>

        <p style={{ fontWeight: "bold" }}>
          {status}
        </p>

        <p>
          سرعت:
          <span
            style={{
              color: "blue",
              fontWeight: "bold",
            }}
          >
            {" "}
            {speed}
          </span>
          {" "}ک‌م/ساعت
        </p>
      </div>

      <MapContainer
        center={position}
        zoom={13}
        style={{
          width: "100%",
          height: "100%",
        }}
      >

        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        <Marker position={position}>
          <Popup>ردیاب لجستیک</Popup>
        </Marker>

        <ChangeMapCenter center={position} />

      </MapContainer>
    </div>
  );
}

export default App;